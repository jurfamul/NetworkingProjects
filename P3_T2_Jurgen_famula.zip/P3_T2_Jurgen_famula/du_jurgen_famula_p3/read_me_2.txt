Jurgen Famula
A.I. Robotics Section 4704
Project 3 task 2
3-15-2021
Read_me

Description:
This package contains all of the source code, executables, and cmake files needed to
launch the wall follow simulation environment and execute the wall_follow behaivor.
Once the simulation enviroment has been initialized, running the Wall_Follow program
will direct the robot to follow the left hand wall. The program accomplishes this by
subscribing to the robot's laser scan topic and descritizing a 180 degree arc, starting
at 340 degrees and ending at 160 degrees, into 9 20 degree arcs. The scan values in each
arc are then averaged and assigned one of 4 states based on the average distance between
the wall and the robot with a value of 3 being the ideal distance. Once the states have
been assigned, the state vector is then passed to the q_follow function which recursively
reads the state of each of the 9 arcs to determine the robot's next action based on the
reward values from the pre-made q table. Task 2 implemented additional functions that
direct the robot to turn when it detects a corner and expanded the q-table based on these
additional actions. Note: Q-learning is non-functional in this build, so a pre-made q-table
was used.

Launch Instructions:
1. open 2 terminals and navigate to your catkin workspace
2. run roslaunch du_jurgen_famula_p3 wallfollow to launch the gazebo simulation evnironment
3. run rosrun du_jurgen_famula_p3 Wall_Follow to launch the q table based wall following program
