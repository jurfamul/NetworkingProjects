/*
* Jurgen Famula
* A.I. Robotics section 4704
* Project 3: Wall_Follow.cpp
*
*/
#include "ros/ros.h"
//libraries used in the transformation listener functionality
#include "geometry_msgs/PointStamped.h"
#include "tf2_ros/transform_listener.h"
#include "tf2_ros/message_filter.h"
#include "message_filters/subscriber.h"
#include "tf2_geometry_msgs/tf2_geometry_msgs.h"
#include "sensor_msgs/LaserScan.h"
#include "geometry_msgs/Twist.h"
#include "std_msgs/String.h"
#include <sstream>
#include <iostream>
#include <fstream>

//structures
struct point {
  float x = 0;
  float y = 0;
  float z = 0;
};

struct action_space {
  int type = 0;
  float x = 0;
  float w = 0;
  float t = 0.1;

  inline bool operator==(const action_space& a) {
       if (a.x==x && a.w== w)
          return true;
       else
          return false;
    }
};

//Wall_Follow class
class Wall_Follow_Pub_Sub
{
  private:
    ros::NodeHandle n_;
    ros::Publisher cmd_pub_;
    ros::Subscriber cmd_sub_;
    ros::Subscriber laser_sub_;
    tf2_ros::Buffer tfBuffer;

    //The distance from the wall that robot will maintain in meters
    float d_wall = 0.5;
    int scan_interval = 120;
    int min_angle = 350;
    int max_angle = 110;
    //the number of possible states and actions (for part 1, 2 actions and 4 states)
    int actions = 3;
    int states = 5;
    int descretization_size = 40;

    //The action spaces that the robot will execute
    action_space forward;
    action_space turn_left;
    action_space turn_right;

    //This laserscan object holds the value of the current LaserScan
    sensor_msgs::LaserScan scan;

    //Q table for part 1 (The outer vectors represents the possible actions,
    // the inner vectors represent the possible states, and the values are the rewards)
    std::vector<int> q_table;

    //callback functions
    void get_laser_message(const sensor_msgs::LaserScan::ConstPtr& msg)
    {
      //ROS_INFO("laser callback");
      /*ROS_INFO("laser scan frame id: %s", msg->header.frame_id.c_str());
      float min = msg->angle_min * (360/(2*3.14159));
      float max = msg->angle_max * (360/(2*3.14159));
      float inc = msg->angle_increment * (360/(2*3.14159));
      std::stringstream s_stream;
      std_msgs::String msgs;
      s_stream << "the size of the range array is " << msg->ranges.size() << ".";
      msgs.data = s_stream.str();
      ROS_INFO("the min angle of the laser scan is %g", min);
      ROS_INFO("the max angle of the laser scan is %g", max);
      ROS_INFO("the increment of the laser scan is %g", inc);
      ROS_INFO("%s", msgs.data.c_str());
      ROS_INFO("the scan time is %g", msg->scan_time);
      ROS_INFO("the min scan range is %g", msg->range_min);
      ROS_INFO("the max scan range is %g", msg->range_max);*/
      scan = *msg;
    }

    void cmd_callback(const geometry_msgs::Twist::ConstPtr& msg)
    {
      //ROS_INFO("The current velocity in the x direction is %g", msg->linear.x);
      //ROS_INFO("The current velocity in the y direction is %g", msg->linear.y);
    }

    //init functions
    //This function populates the Q_table for part 1
    void init_q_table()
    {
      //there are two possible actions for part 1 move_foward and stay_still
      //therefore, there are two vectors to represent them.
      for (int i = 0; i < actions; i++)
      {
        //there are 5 possible q_tabletates as described in the descretize_laser_scan function
        for (int j = 0; j < states; j++)
        {
          //the reward values for each state if the forward action is taken
          if (i == 0)
          {
            if (j == 0)
            {
              q_table.emplace_back(-1);
            }
            else if (j == 1)
            {
              q_table.emplace_back(-1);
            }
            else if (j == 2)
            {
              q_table.emplace_back(0);
            }
            else if (j == 3)
            {
              q_table.emplace_back(-1);
            }
            else
            {
              q_table.emplace_back(-1);
            }
          }
          //the reward values for each state if the turn_right action is taken
          else if (i == 2)
          {
            if (j == 0)
            {
              q_table.emplace_back(-2);
            }
            else if (j == 1)
            {
              q_table.emplace_back(-2);
            }
            else if (j == 2)
            {
              q_table.emplace_back(1);
            }
            else if (j == 3)
            {
              q_table.emplace_back(-2);
            }
            else
            {
              q_table.emplace_back(-2);
            }
          }
          //the reward values for each state if the turn_left action is taken
          else
          {
            if (j == 0)
            {
              q_table.emplace_back(-2);
            }
            else if (j == 1)
            {
              q_table.emplace_back(-2);
            }
            else if (j == 2)
            {
              q_table.emplace_back(1);
            }
            else if (j == 3)
            {
              q_table.emplace_back(-2);
            }
            else
            {
              q_table.emplace_back(-2);
            }
          }
        }
      }
    }

    void init_action_spaces()
    {
      //init forward
      forward.type = 1;
      forward.x = 0.2;

      //init turn_left
      turn_left.type = 2;
      turn_left.x = 0.2;
      turn_left.w = M_PI/4;

      //init turn_right
      turn_left.type = 3;
      turn_right.x = 0.2;
      turn_right.w = -(M_PI/4);
    }

    //get_states function for part 1
    void get_states(std::vector<int>& states)
    {
      //ROS_INFO("Begin get_states");
      //descretize the laser scan data
      int num_states = (int)scan_interval / (int)descretization_size;
      //state 0: left state, state 1: front left state, state 2: front state
      //ROS_INFO("Set min_a");
      int min_a = min_angle;

      //ROS_INFO("begin loop");
      for (int i = 0; i < num_states; i++)
      {
        //ROS_INFO("%d", num_states);
        int max_a = (min_a + descretization_size)%360;
        /*Descretization steps:
        * state 0: collision range (ranges dangously close to the wall defined as the range from 0 to 0.2)
        * state 1: close range (defined as the value of the laser scan being greater then 0.2 but less then d_wall)
        * state 2: goal range (defined as the value being within 0.1 m of d_wall)
        * state 3: far range (defined as a scan result greater then 0.1+d_wall)
        */
        if (min_a > max_a)
        {
          min_a -= 359;
        }
        float avg_range = scan.ranges[min_a];
        int count = 1;
        //ROS_INFO("begin inner loop");
        for (int j = min_a+1; j < max_a; j++)
        {
          //ROS_INFO("%d", j);
          if (j < 0)
          {
            int index = j + 359;
            avg_range += scan.ranges[index];
          }
          else
          {
            //ROS_INFO("get range %g", avg_range);
            avg_range += (float)scan.ranges[j];
          }
          //ROS_INFO("increment count");
          count++;
        }
        avg_range /= count;
        /*ROS_INFO("min_a = %i", min_a);
        ROS_INFO("max_a = %i", max_a);
        ROS_INFO("count = %i", count);
        ROS_INFO("avg_range = %g", avg_range);*/

        if (i == 0 || i == 2)
        {
          if (avg_range <= (d_wall-0.1))
          {
            states.emplace_back(0);
          }
          else if (avg_range > (d_wall-0.1) && avg_range < (d_wall-0.05))
          {
            states.emplace_back(1);
          }
          else if (avg_range >= (d_wall-0.05) && avg_range <= (d_wall+0.05))
          {
            states.emplace_back(2);
          }
          else if (avg_range > (d_wall+0.05) || avg_range <= (d_wall+0.1))
          {
            states.emplace_back(3);
          }
          else
          {
            states.emplace_back(4);
          }
        }
        else
        {
          if (avg_range > (d_wall+0.1))
          {
            states.emplace_back(3);
          }
          else
          {
            states.emplace_back(1);
          }
        }
        min_a = max_a;
      }
    }

    void publish_cmd_vel(action_space a)
    {
      geometry_msgs::Twist cmd;
      cmd.linear.x = a.x;
      cmd.angular.z = a.w;
      cmd_pub_.publish(cmd);
      //ros::Duration(a.t).sleep();
    }

    int q_follow(std::vector<int>& states, action_space a)
    {
      if (states.size() == 1)
      {
        return q_table[states[0]*a.type];
      }
      else
      {
        int cur_state = states.back();
        states.pop_back();
        int cur_reward = q_table[cur_state*a.type];
        int fut_reward = q_follow(states, a);
        if (cur_reward <= fut_reward)
        {
          //publish_cmd_vel(a);
          return fut_reward;
        }
        else
        {
          return cur_reward;
        }
      }
    }

    action_space select_action(std::vector<int> states)
    {
      int L_state = states[2]; //left state
      int LF_state = states[1]; //left forward state
      int F_state = states[0]; //forward state

      if (LF_state == 3)
      {
        if (F_state == 3 && L_state == 3)
        {
          return forward;
        }
        else
        {
          return turn_left;
        }
      }
      else
      {
        if (L_state < 2)
        {
          return turn_right;
        }
        else if (L_state == 2)
        {
          if (F_state <= 3)
          {
            return turn_right;
          }
          else
          {
            return forward;
          }
        }
        else
        {
          return turn_left;
        }
      }
    }

    /*void descretiz_laser_scan(std::vector<std::vector<float>>& states, int min_a, int max_a)
    {
      /*Descretization steps:
      * state 0: collision range (ranges dangously close to the wall defined as the range from 0 to 0.2)
      * vector 1: close range (defined as the value of the laser scan being greater then 0.2 but less then d_wall)
      * vector 2: goal range (defined as the value being within 0.1 m of d_wall)
      * vector 3: far range (defined as a scan result greater then 0.1+d_wall)
      *
      //populate descretization arrays
      for (int i = 0; i < 5; i++)
      {
        std::vector<float> range;
        states.emplace_back(range);
      }

      for (int i = min_a; i < max_a+1; i++)
      {
        float r = scan.ranges[i];
        if (r <= 0.2)
        {
          states[0].emplace_back(r);
        }
        else if (r > 0.2 && r < (d_wall-0.1))
        {
          states[1].emplace_back(r);
        }
        else if (r >= (d_wall-0.1) && r <= (d_wall+0.1))
        {
          states[2].emplace_back(r);
        }
        else if (r > (d_wall+0.1) && r <= 1.2)
        {
          states[3].emplace_back(r);
        }
        else if (r > 1.2)
        {
          states[4].emplace_back(r);
        }
      }
    }*/

  public:
    Wall_Follow_Pub_Sub()
    {
      scan.header.frame_id = "i";
      //ROS_INFO("%s", scan.header.frame_id.c_str());
      cmd_pub_ = n_.advertise<geometry_msgs::Twist>("/cmd_vel", 10);
      cmd_sub_ = n_.subscribe("/cmd_vel", 10, &Wall_Follow_Pub_Sub::cmd_callback, this);
      laser_sub_ = n_.subscribe("/scan", 100, &Wall_Follow_Pub_Sub::get_laser_message, this);
      //ROS_INFO("begin pub_sub");
      this->init_q_table();
      //ROS_INFO("q table initialized");
      this->init_action_spaces();
      //ROS_INFO("action space initialized");
    }

    bool get_node_status()
    {
      return n_.ok();
    }

    //print functions for testing
    void print_laser_array()
    {
      std::string msg = "The laserscan returned: ";
      for (float range : scan.ranges)
      {
        std::stringstream stream;
        stream << "[" << range << "], ";
        msg.append(stream.str());
      }
      ROS_INFO("%s", msg.c_str());
    }

    void print_q_table()
    {
      std::string msg = "The q table is: ";
      for (int reward : q_table)
      {
        std::stringstream stream;
        stream << "[" << reward << "], ";
        msg.append(stream.str());
      }
      ROS_INFO("%s", msg.c_str());
    }

    void print_state_table(std::vector<int> s)
    {
      std::string msg = "The current states are: ";
      for (int state : s)
      {
        std::stringstream stream;
        stream << "[" << state << "], ";
        msg.append(stream.str());
      }
      ROS_INFO("%s", msg.c_str());
    }

    void publish_cmd_vel_test()
    {
      geometry_msgs::Twist cmd;
      cmd.linear.x = 0.1;
      cmd_pub_.publish(cmd);
    }

    //the public function that executes the wall following behavior
    void follow_wall()
    {
      //ROS_INFO("scan frame id: %s", scan.header.frame_id.c_str());
      if (scan.header.frame_id.compare("i") == 0)
      {
        ROS_INFO("error: no scan detected");
      }
      else
      {
        std::vector<int> states;

        //ROS_INFO("initializing state table.");
        get_states(states);

        //ROS_INFO("printing state table");
        print_state_table(states);
        action_space a = select_action(states);
        publish_cmd_vel(a);
        //q_follow(states, forward);
      }
    }
};

int main(int argc, char** argv){

  ros::init(argc, argv,"Wall_Follow");
  Wall_Follow_Pub_Sub w_follow;
  ros::Duration(2.0).sleep();
  ros::Rate r(10);

  while(w_follow.get_node_status())
  {
    //w_follow.print_laser_array();
    //w_follow.publish_cmd_vel_test();
    //w_follow.print_q_table();
    w_follow.follow_wall();
    ros::spinOnce();
    r.sleep();
  }

  return 0;
}
